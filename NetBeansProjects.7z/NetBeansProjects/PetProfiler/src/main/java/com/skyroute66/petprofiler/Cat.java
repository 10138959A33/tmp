
package com.skyroute66.petprofiler;

// Task 2: inherit from the Pet class
public class Cat {
    
    // constructor

    // Task 2: add someName and someAge to the constructor
    
    public Cat() {
        
        // Task 2: call constructor of ancestor class Pet
        // Task 3: add multiplier 8 to constructor call

    }
    
    // methods

    // Task 4: Override selfDescribe() from ancester class.
    //         Call ancester's selfDescribe() then
    //         Add text "Fun cat ready to party! " to string returned

    
}
