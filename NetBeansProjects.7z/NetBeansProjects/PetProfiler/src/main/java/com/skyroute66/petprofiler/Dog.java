
package com.skyroute66.petprofiler;

// Task 2: inhert from the Pet class 
public class Dog {
    
    // constructor
    
    // Task 2: add someName and someAge to the constructor
    
    public Dog() {
        
        // Task 2: call constructor of ancestor class Pet
        // Task 3: add multiplier 7 to constructor call

    }
    
    // methods  
    
    // Task 4: Override selfDescribe() from ancester class.
    //         Call ancester's selfDescribe() then
    //         Add text "Fun dog looking to make friends! " to string returned
    

}
